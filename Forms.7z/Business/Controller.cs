﻿using BeeShopLibrary;
using BeeShopORM.Controller.Repositories;
using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using Business.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Controller
    {/// <summary>
    /// This class contains the methods witch reference to their corresponding repository.
    /// Each table has four methods to work with. Add, Drop(Delete), Update, List(Print data).
    /// The actual methods are in the repositories, but the Business class connect the User with 
    /// the methods.
    /// </summary>
        BeeShopContext c = new BeeShopContext();
        IRepository<Order> orders = new OrderRepository();
        IRepository<Customer> customers = new CustomerRepository();
        IRepository<Delivery> deliveries = new DeliveryRepository();
        IRepository<PayingMethod> payings = new PayingMethodRepository();
        IRepository<Product> products = new ProductRepository();
        IRepository<BasketWithProducts> baskets = new BasketRepository();

        //Customer
        public void AddCustomer(Customer customer)
            =>customers.Add(customer);
        
        public void DropCustomer(int id)
            => customers.Delete(id);      
        public void UpdateCustomer(Customer customer)
            => customers.Update(customer);
        public IEnumerable<Customer> PrintCustomers()       
            => customers.List();
        public Customer FindCustomer(int id)
            => customers.Get(id);
        //Order
        public void AddOrder(Order order)
            =>orders.Add(order);      
        public void DropOrder(int id)
            => orders.Delete(id);      
        public void UpdateOrder(Order order)
            => orders.Update(order);
        public IEnumerable<Order> PrintOrders()
            => orders.List();
        public Order FindOrder(int id)
            => orders.Get(id);
        //Delivery
        public void AddDeliveryMethod(Delivery delivery)
        => deliveries.Add(delivery);
        public void DropDelivery(int id)
            => deliveries.Delete(id);
        public void UpdateDelivery(Delivery delivery)
            => deliveries.Update(delivery);
        public IEnumerable<Delivery> PrintDeliveries()
            => deliveries.List();
        public Delivery FindDelievry(int id)
          => deliveries.Get(id);
        //PayingMethod
        public void AddPayingMethod(PayingMethod paying)
       => payings.Add(paying);
        public void DropPaying(int id)
            => payings.Delete(id);
        public void UpdatePaying(PayingMethod paying)
            => payings.Update(paying);
        public IEnumerable<PayingMethod> PrintPaying()
            => payings.List();
        public PayingMethod FindPaying(int id)
          => payings.Get(id);
        //Product
        public void AddProdut(Product product)
       => products.Add(product);
        public void DropProduct(int id)
            => products.Delete(id);
        public void UpdateProduct(Product product)
            => products.Update(product);
        public IEnumerable<Product> PrintProducts()
            => products.List();
        public Product FindProduct(int id)
          => products.Get(id);
        //Basket
        public void AddBasket(BasketWithProducts basket)
            => baskets.Add(basket);
        public void DropBasket(int id)
            => baskets.Delete(id);
        public void UpdateBasket(BasketWithProducts basket)
            => baskets.Update(basket);
        public IEnumerable<BasketWithProducts> PrintBasket()
            => baskets.List();
        public BasketWithProducts FindBasket(int id)
              => baskets.Get(id);





    }
}
