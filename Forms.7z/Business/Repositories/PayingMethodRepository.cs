﻿using BeeShopLibrary;
using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using Business.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Controller.Repositories
{
    class PayingMethodRepository : IRepository<PayingMethod>
    {
        BeeShopContext con = new();
        public void Add(PayingMethod item)
        {
            con.PayingMethods.Add(item);
            con.SaveChanges();
        }

        public void Delete(int item)
        {
            con.PayingMethods.Remove(con.PayingMethods.Find(item));
            con.SaveChanges();  
        }

        public IEnumerable<PayingMethod> List()
        {
            return con.PayingMethods.ToList();
        }

        public void Update(PayingMethod item)
        {

            PayingMethod customernew = con.PayingMethods.Find(item.Id);
            con.Entry(customernew).CurrentValues.SetValues(item);
            con.SaveChanges();
        }
        public PayingMethod Get(int id)
        {
            return con.PayingMethods.Find(id);
        }
    }
}
