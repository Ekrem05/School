﻿using BeeShopORM.Model.Entities;
using Business;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp
{
    public partial class Form1 : Form
    {
        private Controller controller = new Controller();
        private int editedId=-1;
        public Form1()
        {
            InitializeComponent();
        }
        private void UpdateGrid(string tableName)
        {
            switch (tableName)
            {
                case "Delivery":
                    
                    deliveryDataView.Show();
                    deliveryForms1.Show();
                    deliveryDataView.DataSource = controller.PrintDeliveries();
                    deliveryDataView.ReadOnly = true;
                    deliveryDataView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDelivery_Click(object sender, EventArgs e)
        {
            UpdateGrid("Delivery");
            btnAdd.Visible=true;
            btnAdd.BringToFront();
            btnRemove.Visible = true;
            btnRemove.BringToFront();
            btnUpdate.Visible = true;
            btnUpdate.BringToFront();
          
            lblDescription.Show();
            lblDate.Show();
            txtDescription.Show();

            txtDate.Show();

        }
        private void ClearTextBoxes()
        {

            txtDate.Text = "";
           
            txtDescription.Text = "";

        }
      

        private void btnAdd_Click(object sender, EventArgs e)
        {

            
            string desc = txtDescription.Text;
            DateTime date = DateTime.Now;
            DateTime.TryParse(txtDate.Text,out date);
            controller.AddDeliveryMethod(new Delivery { DeliveryMethod = desc, DeliveryDate = date });
            UpdateGrid("Delivery");
            ClearTextBoxes();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (deliveryDataView.SelectedRows.Count>0)
            {
                var item = deliveryDataView.Rows[0].Cells;
                int id = int.Parse(item[0].Value.ToString());
                controller.DropDelivery(id);
                UpdateGrid("Delivery");
                ClearTextBoxes();
            }
        }
        private void ToggleSaveUpdate()
        {
            if (btnUpdate.Visible)
            {
                btnSave.Visible = true;
                btnUpdate.Visible = false;
            }
            else
            {
                btnSave.Visible = false;
                btnUpdate.Visible = true;
            }
        }
        private void DisableSelect()
        {
            deliveryDataView.Enabled = false;
        }
        private void UpdateTextBoxes(string item,int id)
        {
            if (item=="Delivery")
            {
                Delivery update = controller.FindDelievry(id);
                txtDate.Text = update.DeliveryDate.Date.ToString();
                txtDescription.Text = update.DeliveryMethod;
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (deliveryDataView.SelectedRows.Count > 0)
            {
                var item = deliveryDataView.SelectedRows[0].Cells;
                int id = int.Parse(item[0].Value.ToString());
                editedId = id;
                UpdateTextBoxes("Delivery", id);
                ToggleSaveUpdate();
                DisableSelect();
                
            }
        }
        private  Delivery GetEditedDelivery()
        {
            Delivery item = new Delivery();
            item.DeliveryDate = DateTime.Parse(txtDate.Text);
            item.DeliveryMethod = txtDescription.Text;
            item.Id = editedId;
            return item;
        }
        private void ResetSelect()
        {
            deliveryDataView.ClearSelection();
            deliveryDataView.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Delivery item = GetEditedDelivery();
            controller.UpdateDelivery(item);
            UpdateGrid("Delivery");
            ClearTextBoxes();
            ResetSelect();
            ToggleSaveUpdate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BackColor = Color.Red;
        }
    }
}
