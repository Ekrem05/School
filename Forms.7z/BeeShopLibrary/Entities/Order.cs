﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Model.Entities
{
    public class Order
    {
        [Key]
        public int Id{ get; set; }

        [ForeignKey(nameof(Customer))]
        public int Customer_Id { get; set; }
        public Customer Customer { get; set; }
        [ForeignKey(nameof(PayingMethod))]
        public int PayingMethod_Id { get; set; }
        public PayingMethod PayingMethod { get; set; }
        [ForeignKey(nameof(Delivery))]
        public int Delivery_Id { get; set; }
        public Delivery Delivery { get; set; }

    }
}
