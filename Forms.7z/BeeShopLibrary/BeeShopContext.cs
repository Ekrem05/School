﻿using BeeShopORM.Model.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace BeeShopLibrary
{
    public class BeeShopContext:DbContext
    {
        public DbSet<PayingMethod> PayingMethods { get; set; }
        public DbSet<BasketWithProducts> BasketsWithProducts { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Delivery> DeliveryMethods { get; set; }
        public DbSet<Product> Products { get; set; }
        public BeeShopContext()
        {
            Database.EnsureCreated(); 
        }
        /// <summary>
        /// This method builds the actual connection between the SQL server and the project
        /// </summary>
        /// <param name="optionsBuilder"></param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BeeShop;Integrated Security=True;");
        }

    }
}
