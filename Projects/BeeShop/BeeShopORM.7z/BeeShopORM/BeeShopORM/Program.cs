﻿using BeeShopORM.View;
using System;

namespace BeeShopORM
{
    class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}
