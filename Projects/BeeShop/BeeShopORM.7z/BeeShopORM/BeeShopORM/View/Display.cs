﻿using BeeShopORM.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.View
{
    class Display
    {
        private Business controller = new Business();
        public Display()
        {
            Run();
        }

        private void Run()
        {
            ShowMenu();
            Reader();

        }

        private void ShowTables()
        {
            Console.WriteLine("1.Customers");
            Console.WriteLine("2.Orders");
        }
        private void ShowMenu()
        {
            Console.WriteLine("Select an action");
            Console.WriteLine("1.Add");
            Console.WriteLine("2.Remove");
            Console.WriteLine("3.Update");
            Console.WriteLine("4.List Table");
            Console.WriteLine("5.Exit");
        }
        private void Reader()
        {

            int tableToUse = 1;
            bool menu = true;
            while (menu)
            {

                int n = int.Parse(Console.ReadLine());

                switch (n)
                {
                    case 1:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());

                        switch (tableToUse)
                        {
                            case 1:
                                AddCustomers();
                                break;
                            case 2:
                                AddOrders();
                                break;
                        }

                        break;
                    case 2:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());
                        switch (tableToUse)
                        {
                            case 1:
                                RemoveCustomers();
                                break;
                            case 2:
                                RemoveOrders();
                                break;
                        }

                        break;
                    case 3:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());
                        switch (tableToUse)
                        {
                            case 1:
                                UpdateCustomers();
                                break;
                            case 2:
                                UpdateOrders();
                                break;
                        };
                        break;
                    case 4:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());
                        switch (tableToUse)
                        {
                            case 1:
                                ListCustomers();
                                break;
                            case 2:
                                ListOrders();
                                break;
                        };
                        break;
                    case 5:
                        Console.WriteLine("Good bye!");
                        menu = false;
                        break;


                }
                ShowMenu();
            }
        }

        //Customer
        private void UpdateCustomers()
        {
            Console.WriteLine("Enter Customer id ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter middle name");
            string mid = Console.ReadLine();
            Console.WriteLine("Enter last name");
            string last = Console.ReadLine();
            controller.UpdateCustomer(new Customer() { Id = id, Name = name, MiddleName = mid, LastName = last });

        }

        private void RemoveCustomers()
        {
            Console.WriteLine("Enter Customer Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropCustomer(id);
        }

        private void AddCustomers()
        {

            
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter middle name");
            string mid = Console.ReadLine();
            Console.WriteLine("Enter last name");
            string last = Console.ReadLine();          
            controller.AddCustomer(new Customer() { Name = name, MiddleName = mid, LastName = last });

        }

        private void ListCustomers()
        {
            
                Console.WriteLine(" Id | FirstName | MiddleName | LastName |");
            foreach (var item in controller.PrintCustomers())
            {
                Console.WriteLine($" {item.Id}     {item.Name}        {item.MiddleName}     {item.LastName}  ");
            }
        }
        //Order

        private void ListOrders()   
        {
            Console.WriteLine(" Id |  Customer_ Id | PayingMethod_Id | Delivery_Id |");
            foreach (var item in controller.PrintOrders())
            {
                Console.WriteLine($" {item.Id}      {item.Customer_Id}                {item.PayingMethod_Id}                  {item.Delivery_Id}   ");
            }
        }

        private void RemoveOrders()
        {
            Console.WriteLine("Enter Order Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropOrder(id);
        }

        private void UpdateOrders()
        {
            Console.WriteLine("Enter Order id to update");
            int id = int.Parse(Console.ReadLine());         
            Console.WriteLine("Enter Customer Id");
            int Customer = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Payingmethod's Id");
            int Payingmethod = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Delivery Id");
            int Delivery = int.Parse(Console.ReadLine());
            controller.UpdateOrder(new Order() { Id = id, Customer_Id = Customer, PayingMethod_Id = Payingmethod, Delivery_Id = Delivery });
        }

        private void AddOrders()
        {
        
            Console.WriteLine("Enter Customer Id");
            int Customer = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Payingmethod's Id");
            int Payingmethod = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Delivery Id");
            int Delivery = int.Parse(Console.ReadLine());
            controller.AddOrder(new Order() { Customer_Id = Customer, PayingMethod_Id = Payingmethod, Delivery_Id = Delivery }); ; ;
        }
    }
}
