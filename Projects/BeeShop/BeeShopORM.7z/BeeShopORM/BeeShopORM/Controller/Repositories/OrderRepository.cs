﻿using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Controller.Repositories
{
    class OrderRepository : IRepository<Order>
    {
        BeeShopContext c = new BeeShopContext();
        public void Add(Order order)
        {
            c.Orders.Add(order);
            c.SaveChanges();
        }

        public void Delete(int id)
        {
            Order customer = c.Orders.Find(id);
            c.Orders.Remove(customer);
            c.SaveChanges();
        }

        public IEnumerable<Order> List()
        {
            return c.Orders;
        }

        public void Update(Order order)
        {
            Order customernew = c.Orders.Find(order.Id);
            c.Entry(customernew).CurrentValues.SetValues(order);
            c.SaveChanges();
        }
    }
}
