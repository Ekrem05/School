﻿using BeeShopORM.Controller.Repositories;
using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM
{
    class Business
    {
        BeeShopContext c = new BeeShopContext();
        IRepository<Order> orders = new OrderRepository();
        IRepository<Customer> customers = new CustomerRepository();
        public void AddCustomer(Customer customer)
            =>customers.Add(customer);
        
        public void DropCustomer(int id)
            => customers.Delete(id);
        
        public void UpdateCustomer(Customer customer)
            => customers.Update(customer);
        public IEnumerable<Customer> PrintCustomers()       
            => customers.List();

        public void AddOrder(Order order)
            =>orders.Add(order);
        
        public void DropOrder(int id)
            => orders.Delete(id);
        
        public void UpdateOrder(Order order)
            => orders.Update(order);
        
        public IEnumerable<Order> PrintOrders()
            =>orders.List();
        
        


    }
}
