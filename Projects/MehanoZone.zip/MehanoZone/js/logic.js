const rateButtons = Array.from(document.querySelectorAll(".button-64"));
rateButtons.forEach((button) => button.addEventListener("mousedown", openMenu));
console.log(rateButtons);
function openMenu(e) {
  //
}
