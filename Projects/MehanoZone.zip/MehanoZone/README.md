# MehanoHub
Mini social media for the students of NPTG "Shandor Petyofi" 
