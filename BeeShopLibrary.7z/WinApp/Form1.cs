﻿using BeeShopORM.Model.Entities;
using Business;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp
{
    public partial class Form1 : Form
    {
        private Controller controller = new Controller();
        public Form1()
        {
            InitializeComponent();
        }
        private void UpdateGrid(string tableName)
        {
            switch (tableName)
            {
                case "Delivery":
                    
                    deliveryDataView.Show();
                    deliveryForms1.Show();
                    deliveryDataView.DataSource = controller.PrintDeliveries();
                    deliveryDataView.ReadOnly = true;
                    deliveryDataView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDelivery_Click(object sender, EventArgs e)
        {
            UpdateGrid("Delivery");
            btnAdd.Visible=true;
            btnAdd.BringToFront();
            btnRemove.Visible = true;
            btnRemove.BringToFront();
            btnUpdate.Visible = true;
            btnUpdate.BringToFront();
          
            lblDescription.Show();
            lblDate.Show();
            txtDescription.Show();

            txtDate.Show();

        }
        private void ClearTextBoxes()
        {

            txtDate.Text = "";
           
            txtDescription.Text = "";

        }
      

        private void btnAdd_Click(object sender, EventArgs e)
        {

            
            string desc = txtDescription.Text;
            DateTime date = DateTime.Now;
            DateTime.TryParse(txtDate.Text,out date);
            controller.AddDeliveryMethod(new Delivery { DeliveryMethod = desc, DeliveryDate = date });
            UpdateGrid("Delivery");
            ClearTextBoxes();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
           
        }
    }
}
