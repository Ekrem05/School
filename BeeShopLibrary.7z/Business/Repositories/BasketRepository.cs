﻿using BeeShopLibrary;
using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using Business.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Controller.Repositories
{
    class BasketRepository : IRepository<BasketWithProducts>
    {
        BeeShopContext con = new();

        public void Add(BasketWithProducts item)
        {
            con.BasketsWithProducts.Add(item);
            con.SaveChanges();
        }

        public void Delete(int item)
        {
            con.BasketsWithProducts.Remove(con.BasketsWithProducts.Find(item));
            con.SaveChanges();
        }

        public BasketWithProducts Get(int id)
        {
            return con.BasketsWithProducts.Find(id);
        }

        public IEnumerable<BasketWithProducts> List()
        {
            return con.BasketsWithProducts.ToList();
        }

        public void Update(BasketWithProducts item)
        {
            BasketWithProducts customernew = con.BasketsWithProducts.Find(item.Id);
            con.Entry(customernew).CurrentValues.SetValues(item);
            con.SaveChanges();
        }
    }
}
