﻿using BeeShopLibrary;
using BeeShopORM.Model.Entities;
using Business.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Controller.Repositories
{
    class DeliveryRepository : IRepository<Delivery>
    {
        BeeShopContext con = new();
        public void Add(Delivery item)
        {
            con.DeliveryMethods.Add(item);
            con.SaveChanges();
        }

        public void Delete(int item)
        {
            con.DeliveryMethods.Remove(con.DeliveryMethods.Find(item));
            con.SaveChanges();
        }

        public IEnumerable<Delivery> List()
        {
            return con.DeliveryMethods.ToList();
        }

        public void Update(Delivery item)
        {

            Delivery customernew = con.DeliveryMethods.Find(item.Id);
            con.Entry(customernew).CurrentValues.SetValues(item);
            con.SaveChanges();
        }
        public Delivery Get(int id)
        {
            return con.DeliveryMethods.Find(id);
        }
    }
}
