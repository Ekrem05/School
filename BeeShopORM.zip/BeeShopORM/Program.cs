﻿using BeeShopORM.View;
using System;

namespace BeeShopORM
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {               
                    Display display = new Display();               
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
           
        }
    }
}
