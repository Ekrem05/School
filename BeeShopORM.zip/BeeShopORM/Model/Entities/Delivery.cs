﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Model.Entities
{
    class Delivery
    {
        [Key]
        public int Id { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string DeliveryMethod { get; set; }
        ICollection<Order> Orders { get; set; }
    }
}
