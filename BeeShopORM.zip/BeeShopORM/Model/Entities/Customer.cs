﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Model.Entities
{
    class Customer
    {   [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [StringLength(14)]
        public string MiddleName { get; set; }
        [StringLength(14)]
        public string LastName { get; set; }

        ICollection<Order> Orders { get; set; }

    }
}
