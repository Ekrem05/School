﻿using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.View
{
    class Display
    {
        /// <summary>
        /// This class represent everything that is displayed on the console.
        /// It communicates with the user and helps him with the manipulation of table data
        /// </summary>
        private Business controller = new Business();
       
        public Display()
        {
            Run();
        }

        private void Run()
        {
            ShowMenu();
            Reader();

        }

        private void ShowTables()
        {
            Console.WriteLine("1. Customers");
            Console.WriteLine("2. Orders");
            Console.WriteLine("3. Delivery Methods");
            Console.WriteLine("4. Products");
            Console.WriteLine("5. PayingMethods");
            Console.WriteLine("6. Baskets");
        }
        private void ShowMenu()
        {
            Console.WriteLine("Select an action");
            Console.WriteLine("1.Add");
            Console.WriteLine("2.Remove");
            Console.WriteLine("3.Update");
            Console.WriteLine("4.List Table");
            Console.WriteLine("5.Exit");
        }
        private void Reader()
        {

            int tableToUse = 1;
            bool menu = true;
            while (menu)
            {

                int n = int.Parse(Console.ReadLine());

                switch (n)
                {
                    case 1:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());

                        switch (tableToUse)
                        {
                            case 1:

                                AddCustomers();
                                break;
                            case 2:
                                AddOrders();
                                break;
                            case 3:
                                AddDelivery();
                                break;
                            case 4:
                                AddProduct();
                                break;
                            case 5:
                                AddPayingMethod();
                                break;
                            case 6:
                                AddBasket();
                                break;
                        }

                        break;
                    case 2:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());
                        switch (tableToUse)
                        {
                            case 1:
                                RemoveCustomers();
                                break;
                            case 2:
                                RemoveOrders();
                                break;
                            case 3:
                                RemoveDelivery();
                                break;
                            case 4:
                                RemoveProduct();
                                break;
                            case 5:
                                RemovePayingMethod();
                                break;
                            case 6:
                                RemoveBasket();
                                break;
                        }

                        break;
                    case 3:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());
                        switch (tableToUse)
                        {
                            case 1:
                                UpdateCustomers();
                                break;
                            case 2:
                                UpdateOrders();
                                break;
                            case 3:
                                UpdateDelivery();
                                break;
                            case 4:
                                UpdateProduct();
                                break;
                            case 5:
                                UpdatePayingMethod();
                                break;
                            case 6:
                                UpdateBasket();
                                break;
                        };
                        break;
                    case 4:
                        ShowTables();
                        tableToUse = int.Parse(Console.ReadLine());
                        switch (tableToUse)
                        {
                            case 1:
                                ListCustomers();
                                break;
                            case 2:
                                ListOrders();
                                break;
                            case 3:
                                ListDelivery();
                                break;
                            case 4:
                                ListProduct();
                                break;
                            case 5:
                                ListPayingMethods();
                                break;
                            case 6:
                                ListBasket();
                                break;
                        };
                        break;
                    case 5:
                        Console.WriteLine("Good bye!");
                        menu = false;
                        break;


                }
                if (n!=5)
                {
                    ShowMenu();
                }
                
            }
        }

        //Customer
        private void UpdateCustomers()
        {
            Console.WriteLine("Available customers: ");
            ListCustomers();
            Console.WriteLine();
            Console.WriteLine("Enter Customer id ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("What do you want to update?");
            Console.WriteLine("1. Name");
            Console.WriteLine("2. Mid name");
            Console.WriteLine("3. Last name");
            Console.WriteLine("4. All");
            int table = int.Parse(Console.ReadLine());
            Customer customerUpdated = controller.FindCustomer(id);
            switch (table)
            {
                case 1:
                    Console.WriteLine("Enter Name");
                     string name = Console.ReadLine();
                    customerUpdated.Name = name;
                    break;
                case 2:
                    Console.WriteLine("Enter middle name");
                    string mid = Console.ReadLine();
                    customerUpdated.MiddleName = mid;
                    break;
                case 3:
                    Console.WriteLine("Enter last name");
                    string last = Console.ReadLine();
                    customerUpdated.LastName = last ;
                    break;
                case 4:
                    Console.WriteLine("Enter Name");
                     name = Console.ReadLine();
                    Console.WriteLine("Enter middle name");
                     mid = Console.ReadLine();
                    Console.WriteLine("Enter last name");
                     last = Console.ReadLine();
                    customerUpdated.Name = name;
                    customerUpdated.MiddleName = mid;
                    customerUpdated.LastName = last;
                    break;
            }
            controller.UpdateCustomer(customerUpdated);

        }
        private void RemoveCustomers()
        {
            Console.WriteLine("Enter Customer Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropCustomer(id);
        }
        private void AddCustomers()
        {

            
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter middle name");
            string mid = Console.ReadLine();
            Console.WriteLine("Enter last name");
            string last = Console.ReadLine();          
            controller.AddCustomer(new Customer() { Name = name, MiddleName = mid, LastName = last });

        }
        private void ListCustomers()
        {
            int[] widths = { 3, 20, 12, 12 }; // Define the widths for each column
            //Заглавия на колоните - антетка
            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  "Id", "FirstName", "MiddleName", "LastName");
            //ПОДЧЕРТАВАЩА ЛИНИЯ
            Console.WriteLine(new string('-', 60));
            //данни от таблицата ОР БД
            List<Customer> customers = controller.PrintCustomers().ToList();
            for (int i = 0; i < customers.Count; i++)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  customers[i].Id, customers[i].Name, customers[i].MiddleName, customers[i].LastName);
            }
            //ПОДЧЕРТАВАЩА ЛИНИЯ
            Console.WriteLine(new string('-', 60));
        }

        //Order
        private void ListOrders()   
        {
            int[] widths = { 4, 13, 16, 13 }; 
            
            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  "Id", "Customer_ Id", "PayingMethod_Id", "Delivery_Id");
           
            Console.WriteLine(new string('-', 60));
           
            List<Order> orders = controller.PrintOrders().ToList();
            for (int i = 0; i < orders.Count; i++)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  orders[i].Id, orders[i].Customer_Id, orders[i].PayingMethod_Id, orders[i].Delivery_Id);
            }
           
            Console.WriteLine(new string('-', 60));
        }
        private void RemoveOrders()
        {
            Console.WriteLine("Enter Order Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropOrder(id);
        }
        private void UpdateOrders()
        {
            Console.WriteLine("Available Orders: ");
            ListOrders();
            Console.WriteLine("Enter Order id to update");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("What do you want to update?");
            Console.WriteLine("1. Customer Id");
            Console.WriteLine("2. Paying method Id");
            Console.WriteLine("3. Delivery Id");
            Console.WriteLine("4. All");
            int table = int.Parse(Console.ReadLine());
            Order orderUpdated = controller.FindOrder(id);
            switch (table)
            {
                case 1:
                    Console.WriteLine("Customers: ");
                    ListCustomers();
                    Console.WriteLine();
                    Console.WriteLine("Enter Customer Id");
                    int customer = int.Parse(Console.ReadLine());
                    orderUpdated.Customer_Id = customer;
                    break;
                case 2:
                    Console.WriteLine("Paying methods: ");
                    ListPayingMethods();
                    Console.WriteLine();
                    Console.WriteLine("Enter Paying method's Id");
                    int payingmethod = int.Parse(Console.ReadLine());
                    orderUpdated.PayingMethod_Id = payingmethod;
                    break;
                case 3:
                    Console.WriteLine("Delivery methods: ");
                    ListDelivery();
                    Console.WriteLine();
                    Console.WriteLine("Enter Delivery Id");
                    int delivery = int.Parse(Console.ReadLine());
                    orderUpdated.Delivery_Id = delivery;
                    break;
                case 4:
                    Console.WriteLine("Customers: ");
                    ListCustomers();
                    Console.WriteLine();
                    Console.WriteLine("Enter Customer Id");
                     customer = int.Parse(Console.ReadLine());
                    orderUpdated.Customer_Id = customer;
                    Console.WriteLine("Paying methods: ");
                    ListPayingMethods();
                    Console.WriteLine();
                    Console.WriteLine("Enter Paying method's Id");
                     payingmethod = int.Parse(Console.ReadLine());
                    orderUpdated.PayingMethod_Id = payingmethod;
                    Console.WriteLine("Delivery methods: ");
                    ListDelivery();
                    Console.WriteLine();
                    Console.WriteLine("Enter Delivery Id");
                     delivery = int.Parse(Console.ReadLine());
                    orderUpdated.Delivery_Id = delivery;
                    break;
            }
            controller.UpdateOrder(orderUpdated);

         
        }
        private void AddOrders()
        {
            Console.WriteLine("Customers: ");
            ListCustomers();
            Console.WriteLine();
            Console.WriteLine("Enter Customer Id");
            int Customer = int.Parse(Console.ReadLine());

            Console.WriteLine("Paying methods: ");
            ListPayingMethods();
            Console.WriteLine();
            Console.WriteLine("Enter Paying method's Id");
            int Payingmethod = int.Parse(Console.ReadLine());

            Console.WriteLine("Delivery methods: ");
            ListDelivery();
            Console.WriteLine();
            Console.WriteLine("Enter Delivery Id");
            int Delivery = int.Parse(Console.ReadLine());
            controller.AddOrder(new Order() { Customer_Id = Customer, PayingMethod_Id = Payingmethod, Delivery_Id = Delivery }); ; ;
        }

        //Delivery
        private void ListDelivery()
        {
            //Console.WriteLine(" Id |  Date | Description |");
            //foreach (var item in controller.PrintDeliveries())
            //{
            //    Console.WriteLine($" {item.Id}      {item.DeliveryDate}                {item.DeliveryMethod}              ");
            //}
            int[] widths = { 4, 13, 16, 13 };

            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "}",
                                  "Id", "Date", "Description");

            Console.WriteLine(new string('-', 60));

            List<Delivery> deliveries = controller.PrintDeliveries().ToList();
            for (int i = 0; i < deliveries.Count; i++)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "}",
                                  deliveries[i].Id, $"{deliveries[i].DeliveryDate.Year}.{deliveries[i].DeliveryDate.Month}.{deliveries[i].DeliveryDate.Day}", deliveries[i].DeliveryMethod);
            }

            Console.WriteLine(new string('-', 60));
        }
        private void RemoveDelivery()
        {
            Console.WriteLine("Enter Delivery Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropDelivery(id);
        }
        private void UpdateDelivery()
        {
            Console.WriteLine("Available delivery mthods: ");
            ListDelivery();
            Console.WriteLine();
            Console.WriteLine("Enter Delivery id to update");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("What do you want to update?");
            Console.WriteLine("1. Delivery date");
            Console.WriteLine("2. Description");
            Console.WriteLine("4. All");

            int table = int.Parse(Console.ReadLine());
            Delivery deliveryUpdated = controller.FindDelievry(id);
            switch (table)
            {
                case 1:
                    Console.WriteLine("Enter Delivery date");
                    DateTime date = DateTime.Parse(Console.ReadLine());
                    deliveryUpdated.DeliveryDate = date;
                    break;
                case 2:
                    Console.WriteLine("Enter description");
                    string description = Console.ReadLine();
                    deliveryUpdated.DeliveryMethod = description;
                    break;
                case 3:
                    Console.WriteLine("Enter Delivery date");
                     date = DateTime.Parse(Console.ReadLine());
                    deliveryUpdated.DeliveryDate = date;
                    Console.WriteLine("Enter description");
                     description = Console.ReadLine();
                    deliveryUpdated.DeliveryMethod = description;
                    deliveryUpdated.DeliveryDate = date;
                    break;
            }
            controller.UpdateDelivery(deliveryUpdated);
        }
        private void AddDelivery()
        {

            Console.WriteLine("Enter Delivery date");
            DateTime date = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Enter description");
           string description = Console.ReadLine();          
            controller.AddDeliveryMethod(new Delivery() { DeliveryDate = date,DeliveryMethod=description}); ; ;
        }

        //Product
        private void ListProduct()
        {
            int[] widths = { 4, 20, 10, 13 };

            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  "Id", "Name", "Price", "In Stock");

            Console.WriteLine(new string('-', 60));

            List<Product> products = controller.PrintProducts().ToList();
            for (int i = 0; i < products.Count; i++)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  products[i].Id, products[i].ProductName, products[i].Price, products[i].StockLeft);
            }

            Console.WriteLine(new string('-', 60));
        }
        private void RemoveProduct()
        {
            Console.WriteLine("Enter Product Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropProduct(id);
        }
        private void UpdateProduct()
        {
            Console.WriteLine("Available products: ");
            ListProduct();
            Console.WriteLine();
            Console.WriteLine("Enter Product id to update");
            int id = int.Parse(Console.ReadLine()); Console.WriteLine("What do you want to update?");
            Console.WriteLine("1. Product name");
            Console.WriteLine("2. Price");
            Console.WriteLine("4. Stock");
            Console.WriteLine("5. All");

            int table = int.Parse(Console.ReadLine());
            Product productUp = controller.FindProduct(id);
            string name=string.Empty;
            double price = -1;
            int stock = -1;
            switch (table)
            {
                case 1:
                    Console.WriteLine("Enter Product name");
                     name = Console.ReadLine();
                    productUp.ProductName = name;
                    break;
                case 2:
                    Console.WriteLine("Enter price");
                    price = double.Parse(Console.ReadLine());
                    productUp.Price = price;
                    break;
                case 3:
                    Console.WriteLine("Enter stock");
                    stock = int.Parse(Console.ReadLine());
                    break;
                case 4:
                    Console.WriteLine("Enter Product name");
                    name = Console.ReadLine();
                    Console.WriteLine("Enter price");
                    price = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter stock left");
                    stock = int.Parse(Console.ReadLine());
                    break;
            }
            
            controller.UpdateProduct(new Product() { Id =controller.FindProduct(id).Id, ProductName = name, Price = price, StockLeft = stock }) ; ; ;
        }
        private void AddProduct()
        {
            Console.WriteLine("Enter Product name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter price");
            double price = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter stock left");
            int stock = int.Parse(Console.ReadLine());           
            controller.AddProdut(new Product() {ProductName=name,Price=price,StockLeft=stock}); ; ;
        }

        //PayingMethod
        private void ListPayingMethods()
        {
            int[] widths = { 4, 20};

            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "}",
                                  "Id", "Description");

            Console.WriteLine(new string('-', 30));

            List<PayingMethod> payingMethods = controller.PrintPaying().ToList();
            for (int i = 0; i < payingMethods.Count; i++)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "}",
                                  payingMethods[i].Id, payingMethods[i].Description);
            }

            Console.WriteLine(new string('-', 30));
        }
        private void RemovePayingMethod()
        {
            Console.WriteLine("Enter Paying method Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropPaying(id);
        }
        private void UpdatePayingMethod()
        {
            Console.WriteLine("Available Paying methods: ");
            ListPayingMethods();
            Console.WriteLine();
            Console.WriteLine("Enter Paying method id to update");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter paying method descroption");
            string description = Console.ReadLine();
            controller.UpdatePaying(new PayingMethod() { Id = controller.FindPaying(id).Id, Description = description });
        }
        private void AddPayingMethod()
        {
            Console.WriteLine("Enter Paying method descroption"); 
            string description = Console.ReadLine();           
            controller.AddPayingMethod(new PayingMethod() {Description=description});
        }

        //Basket
        private void ListBasket()
        {
            int[] widths = { 4, 11,11, 13 };

            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  "Id", "Product_Id", "Order_Id", "Quantity");

            Console.WriteLine(new string('-', 60));

            List<BasketWithProducts> bip = controller.PrintBasket().ToList();
            for (int i = 0; i < bip.Count; i++)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}",
                                  bip[i].Id, bip[i].Product_Id, bip[i].Order_Id, bip[i].Quantity);
            }

            Console.WriteLine(new string('-', 60));
        }
        private void RemoveBasket()
        {
            Console.WriteLine("Enter Basket Id");
            int id = int.Parse(Console.ReadLine());
            controller.DropBasket(id);
        }
        private void UpdateBasket()
        {
            Console.WriteLine("Available basket: ");
            ListBasket();
            Console.WriteLine();

            Console.WriteLine("Enter Basket id to update");
            int id = int.Parse(Console.ReadLine());

            Console.WriteLine("What do you want to update?");
            Console.WriteLine("1. Product ");
            Console.WriteLine("2. Order");
            Console.WriteLine("4. Quantity");
            Console.WriteLine("5. All");

            int table = int.Parse(Console.ReadLine());
            BasketWithProducts basket = controller.FindBasket(id);
            int product = -1;
            int order = -1;
            int quantity = -1;

            switch (table)
            {
                case 1:
                    Console.WriteLine("Enter Product id");
                    ListProduct();
                    product = int.Parse(Console.ReadLine());
                    basket.Product_Id = product;
                    break;
                case 2:
                    Console.WriteLine("Enter Order id");
                    ListOrders();

                    order = int.Parse(Console.ReadLine());
                    basket.Order_Id = order;
                    break;
                case 3:
                    Console.WriteLine("Enter quantity");
                    quantity = int.Parse(Console.ReadLine());
                    basket.Quantity = quantity;
                    break;
                case 4:
                    Console.WriteLine("Available products: ");
                    ListProduct();
                    Console.WriteLine();
                    Console.WriteLine("Enter Product id");
                     product = int.Parse(Console.ReadLine());
                    Console.WriteLine("Available orders: ");
                    ListOrders();
                    Console.WriteLine();
                    Console.WriteLine("Enter Order id");
                     order = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter quantity");
                     quantity = int.Parse(Console.ReadLine());
                    break;
            }
           
            controller.UpdateBasket(new BasketWithProducts() { Id = controller.FindBasket(id).Id, Product_Id = product, Order_Id = order, Quantity = quantity });
        }
        private void AddBasket()
        {
            Console.WriteLine("Available products: ");
            ListProduct();
            Console.WriteLine();
            Console.WriteLine("Enter Product id");
            int product = int.Parse(Console.ReadLine());
            Console.WriteLine("Available orders: ");
            ListOrders();
            Console.WriteLine();
            Console.WriteLine("Enter Order id");
            int order = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter quantity");
            int quantity = int.Parse(Console.ReadLine());
            controller.AddBasket(new BasketWithProducts() { Product_Id=product, Order_Id=order,Quantity=quantity});
        }
    }
}
