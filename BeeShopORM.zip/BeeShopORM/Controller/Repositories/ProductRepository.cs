﻿using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Controller.Repositories
{
    class ProductRepository : IRepository<Product>
    {
        BeeShopContext con = new();

        public void Add(Product item)
        {
            con.Products.Add(item);
            con.SaveChanges();
        }

        public void Delete(int item)
        {
            con.Products.Remove(con.Products.Find(item));
            con.SaveChanges();
        }

        public IEnumerable<Product> List()
        {
            return con.Products.ToList();
        }

        public void Update(Product item)
        {
            Product customernew = con.Products.Find(item.Id);
            con.Entry(customernew).CurrentValues.SetValues(item);
            con.SaveChanges();
        }
        public Product Get(int id)
        {
            return con.Products.Find(id);
        }
    }
}
