﻿using BeeShopORM.Model;
using BeeShopORM.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeShopORM.Controller.Repositories
{
    class CustomerRepository : IRepository<Customer>
    {
        BeeShopContext c = new BeeShopContext();
        public void Add(Customer customer)
        {
            c.Customers.Add(customer);
            c.SaveChanges();
        }
        public void Delete(int id)
        {
            Customer customer = c.Customers.Find(id);
            c.Customers.Remove(customer);
            c.SaveChanges();
        }
        public void Update(Customer customer)
        {
            Customer customernew = c.Customers.Find(customer.Id);
            c.Entry(customernew).CurrentValues.SetValues(customer);
            c.SaveChanges();
        }
        public IEnumerable<Customer> List()
        {
            return c.Customers.ToList();
        }
        public Customer Get(int id)
        {
            return c.Customers.Find(id);
        }
    }
}
