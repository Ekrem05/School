﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AvtokushtaMvc.Data
{
    public class Vehicle
    {
        [Key]
        public Guid Id { get; set; }

        [MaxLength(30)]
        [Required]
        public string Make { get; set; }

        [MaxLength(30)]
        [Required]
        public string Model { get; set; }

        [Required]
        public double Price { get; set; }

        [Required]
        public string ModelYear { get; set; }

        [Required]
        public DateTime RegistrationDate { get; set; }

        [Required]
        public DateTime AdDate { get; set; }

        [MaxLength(500)]
        [Required]
        public string Description { get; set; }

        [Required]
        public string ImageUrl { get; set; }

        [MaxLength(30)]
        [Required]
        public string Horsepower { get; set; }

        [ForeignKey(nameof(CategoryId))]
        public string CategoryId { get; set; }
        public Category Category { get; set; }

        [Required]
        public string SellerId { get; set; }
        public IdentityUser Seller{ get; set; }

        public ICollection<VehicleBookmarks> VehicleBookmarks { get; set; } = new HashSet<VehicleBookmarks>();


    }
}
