﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace AvtokushtaMvc.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Vehicle> Vehicles { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<VehicleBookmarks> VehicleSellers { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<VehicleBookmarks>()
                .HasKey(vs => new { vs.UserId, vs.VehicleId });
            builder.Entity<VehicleBookmarks>()
                .HasOne(vs => vs.Vehicle)
                .WithMany(v => v.VehicleBookmarks)
                .OnDelete(DeleteBehavior.NoAction);

            builder.Entity<Category>()
                .HasData(new Category()
                {
                    Id=Guid.NewGuid(),
                    Name = "Car"
                }, new Category()
                {
                    Id = Guid.NewGuid(),
                    Name = "Bus"
                }, new Category()
                {
                    Id = Guid.NewGuid(),
                    Name = "Motorcycle"
                });

            base.OnModelCreating(builder);
        }

    }
}
