﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace AvtokushtaMvc.Data
{
    public class VehicleBookmarks
    {
        [ForeignKey(nameof(VehicleId))]
        public int VehicleId { get; set; }
        public Vehicle Vehicle { get; set; }

        [ForeignKey(nameof(UserId))]
        public int UserId { get; set; }
        public IdentityUser User { get; set; }
    }
}