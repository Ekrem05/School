﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace AvtokushtaMvc.Models.ViewModel
{
    public class VehicleAddViewModel
    {
        [AllowNull]
        public string Id { get; set; }

        [MaxLength(30)]
        [Required]
        public string Make { get; set; }

        [MaxLength(30)]
        [Required]
        public string Model { get; set; }

        [Range(1,1000000)]
        [Required]
        public double Price { get; set; }

        [Required]
        public string ModelYear { get; set; }


        [Required]
        public string RegistrationDate { get; set; }

        [MaxLength(500)]
        [Required]
        public string Description { get; set; }

        [Required]
        public string ImageUrl { get; set; }

        [MaxLength(30)]
        [Required]
        public string Horsepower { get; set; }

        [Required]
        public string CategoryId { get; set; }

        public ICollection<CategoryViewModel> Categories { get; set; } = new List<CategoryViewModel>();

    }
}
