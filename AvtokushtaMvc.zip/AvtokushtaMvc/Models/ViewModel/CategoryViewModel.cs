﻿namespace AvtokushtaMvc.Models.ViewModel
{
    public class CategoryViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }

    }
}