﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AvtokushtaMvc.Models.ViewModel
{
    public class VehicleViewModel
    {
        public string Id { get; set; }

        public string Make { get; set; }

        public string Model { get; set; }
        public string ImageUrl { get; set; }

        public string Price { get; set; }
        public string AdDate { get; set; }

        public string ModelYear { get; set; }

        public string RegistrationDate { get; set; }

        public string Horsepower { get; set; }
        public string SellerName { get; set; }
    }
}
