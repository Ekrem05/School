﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AvtokushtaMvc.Validation
{
    public static class ValidationValues
    {
        public const string DateFormat = "dd/MM/yyyy";
    }
}
