﻿using AvtokushtaMvc.Data;
using AvtokushtaMvc.Models.ViewModel;
using AvtokushtaMvc.Validation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AvtokushtaMvc.Controllers
{

    public class AdController : Controller
    {
        private ApplicationDbContext dbContext;
        public AdController(ApplicationDbContext _dbContext)
        {
            dbContext = _dbContext;
        }

        [ActionName("All")]
        public async Task<IActionResult> Index()
        {
            var ads = dbContext.Vehicles
                .Include(v=>v.Seller)
                .Select(e => new VehicleViewModel()
                {
                    Id = e.Id.ToString(),
                    Make = e.Make,
                    Model = e.Model,
                    Price=e.Price.ToString(),
                    ImageUrl=e.ImageUrl,
                    ModelYear=e.ModelYear,
                    AdDate=e.AdDate.ToString(ValidationValues.DateFormat),
                    RegistrationDate = e.RegistrationDate.ToString(ValidationValues.DateFormat),
                    Horsepower = e.Horsepower,
                    SellerName =e.Seller.UserName
                })
                .ToList();
            return View(ads);
        }
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> Add()
        {
            VehicleAddViewModel vm = new VehicleAddViewModel();
            vm.Categories = GetCategories();
            return View(vm);
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Add(VehicleAddViewModel vm)
        {
            var year = DateTime.Now;
            
            if (!DateTime
                .TryParseExact(vm.RegistrationDate,
                "dd/MM/yyyy",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out year))
            {
                ModelState.AddModelError(nameof(vm.RegistrationDate), $"Date format must be {ValidationValues.DateFormat}");
            }
            if (!ModelState.IsValid)
            {
                return RedirectToAction(nameof(Add));
            }
            Vehicle eventModel = new Vehicle()
            {
                Make = vm.Make,
                Model = vm.Model,
                RegistrationDate = year,
                AdDate=DateTime.Now,
                ImageUrl=vm.ImageUrl,
                Price=vm.Price,
                Description=vm.Description,
                ModelYear =vm.ModelYear,
                Horsepower = vm.Horsepower,
                CategoryId = vm.CategoryId,
                SellerId = GetUserId(),
            };

            await dbContext.Vehicles.AddAsync(eventModel);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("All");
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> Edit(string Id)
        {
            var vehicle = await GetVehicleById(Id);
            VehicleAddViewModel vm = new VehicleAddViewModel();
            vm.Make = vehicle.Make;
            vm.Model = vm.Model;
            vm.ModelYear = vm.ModelYear;
            vm.Horsepower = vehicle.Horsepower;
            vm.Price = vehicle.Price;
            vm.ImageUrl = vehicle.ImageUrl;
            vm.Description = vehicle.Description;
            vm.CategoryId = vehicle.CategoryId;
            vm.RegistrationDate = vm.RegistrationDate;
            vm.Categories = GetCategories();
            return View(vm);
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Edit(VehicleAddViewModel vm)
        {
            var year = DateTime.Now;

            if (!DateTime
                .TryParseExact(vm.RegistrationDate,
                "dd/MM/yyyy",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out year))
            {
                ModelState.AddModelError(nameof(vm.RegistrationDate), $"Date format must be {ValidationValues.DateFormat}");
            }
            if (!ModelState.IsValid)
            {
                return RedirectToAction(nameof(Add));
            }
            var vehicle = await GetVehicleById(vm.Id);
            vehicle.Make = vm.Make;
            vehicle.Model = vm.Model;
            vehicle.ModelYear = vm.ModelYear;
            vehicle.Horsepower = vm.Horsepower;
            vehicle.Price = vm.Price;
            vehicle.ImageUrl = vm.ImageUrl;
            vehicle.Description = vm.Description;
            vehicle.CategoryId = vm.CategoryId;
            vehicle.RegistrationDate = year;
            await dbContext.SaveChangesAsync();
            return RedirectToAction("All");

        }

        private async Task<Vehicle> GetVehicleById(string id)
        {
            return await dbContext.Vehicles.FirstOrDefaultAsync(v => v.Id.ToString() == id);
        }

        private string GetUsername()
        {
            return User.FindFirst(ClaimTypes.Name)?.Value ?? string.Empty;
        }
        private string GetUserId()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? string.Empty;
        }
        private List<CategoryViewModel> GetCategories()
        {
            return dbContext.Categories
                .Select(t => new CategoryViewModel()
                {
                    Id = t.Id.ToString(),
                    Name = t.Name,
                })
                .ToList();
        }
    }
}
